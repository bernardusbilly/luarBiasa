$(window).load(function() {
	$('.loading-wrapper').hide();
  	$('.loading-logo').css("height", "60px");
});